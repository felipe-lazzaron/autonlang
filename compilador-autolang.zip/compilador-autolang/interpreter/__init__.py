# A presença de um arquivo __init__.py em um diretório indica ao Python que o diretório deve 
# ser tratado como um pacote. Isso permite a importação de módulos dentro do diretório como parte de um pacote.
